If you've installed MotionBuilder in the default places on your C drive you'll be better off
downloading the version of my plugins with installer, as it'll copy things automatically.


If you haven't isntalled in the default folders, search for these folders inside your MotionBuilder installation folder:

\bin\win32\plugins
\bin\x64\plugins

So for example:
C:\Program Files (x86)\Autodesk\MotionBuilder 2009\bin\win32\plugins
C:\Program Files (x86)\Autodesk\Autodesk MotionBuilder 2011 32-bit\bin\win32\plugins
C:\Program Files (x86)\Autodesk\MotionBuilder 2009\bin\x64\plugins
C:\Program Files\Autodesk\Autodesk MotionBuilder 2011 Subscription Advantage Pack 64-bit\bin\x64\plugins


Place the matching .dll file(s) from the zip in there and the device should show up when you start MoBu
